Study Tracker - Android project
Web app: app/src/main/assets/index.html
Build: GitHub Actions (.github/workflows/build.yml) ya Android Studio (Build > Build APK).
